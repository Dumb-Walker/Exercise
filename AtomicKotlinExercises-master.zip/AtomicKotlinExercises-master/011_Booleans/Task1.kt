//Booleans/Task1.kt
package booleansExercise1

// (178 + 131 > 209 + 99) && false
val a: Boolean = false

// 1 > 2 || 1 < 2
val b: Boolean = true

// (111 - 101 >= 10) && (11.0 > 10.99) && true
val c: Boolean = true
