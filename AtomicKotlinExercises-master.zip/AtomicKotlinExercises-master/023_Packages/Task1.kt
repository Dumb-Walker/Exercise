//Packages/Task1.kt
package packagesExercise1

import kotlin.math.E
import kotlin.math.PI

fun main() {
  println(PI)
  println(E)
}
