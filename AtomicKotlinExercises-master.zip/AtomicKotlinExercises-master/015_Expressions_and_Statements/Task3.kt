//ExpressionsStatements/Task3.kt
package expressionsAndStatementsExercise3

/*
var i = 1
println(i-- - --i)
*/
val yourGuess: Int = 2
