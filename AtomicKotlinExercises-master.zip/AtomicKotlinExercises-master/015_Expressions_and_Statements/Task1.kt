//ExpressionsStatements/Task1.kt
package expressionsAndStatementsExercise1

fun main() {
  println(println(1))
}
