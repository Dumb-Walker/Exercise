//Varargs/Task1.kt
package variableArgumentListsExercise1

// fun foo(vararg i: Int, vararg s: String) {}

fun main() {
  println("Multiple vararg-parameters are prohibited")
}
