//Summary1/Task1.kt
package summaryIExercise1

fun main() {
  var x = 1
  val y = x
  val z = y
  x = 2
  println(x)
  println(y)
  println(z)
}
