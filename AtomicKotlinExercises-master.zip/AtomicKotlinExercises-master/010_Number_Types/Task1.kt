//NumberTypes/Task1.kt
package numberTypesExercise1

// 11 / 3
val a = 3

// 11 % 3
val b = 2

// a * 3 + b
val c = 11

// 6 / 5.0
val d = 1.2
