//NullableTypes/Task2.kt
package nullableTypesExercise2

// type your solution here
