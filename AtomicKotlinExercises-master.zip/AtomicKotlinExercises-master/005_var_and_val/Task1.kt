//VarAndVal/Task1.kt
package varAndValExercise1

fun main() {
  var answer = 42
  answer = 43
  println(answer)
}
