//VarAndVal/ccc.kt
package varAndValExercise2

fun main() {
  var a = 10
  val b = a
  a = 42
  println(a)
  println(b)
}
