//Functions/Task1.kt
package functionsExercise1

fun getSquare(i: Int): Int = i * i

fun main() {
  println(getSquare(2))  // 4
}
