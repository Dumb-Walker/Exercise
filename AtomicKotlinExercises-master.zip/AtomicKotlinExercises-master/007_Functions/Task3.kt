//Functions/Task3.kt
package functionsExercise3

fun duplicate(s: String): String = s + s

fun main() {
  println(duplicate("abc"))  // abcabc
}
