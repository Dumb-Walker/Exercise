//Functions/Task2.kt
package functionsExercise2

fun getSum(a: Double, b: Double, c: Double): Double = a + b + c

fun main() {
  println(getSum(1.0, 2.2, 3.4))  // 6.6
}
