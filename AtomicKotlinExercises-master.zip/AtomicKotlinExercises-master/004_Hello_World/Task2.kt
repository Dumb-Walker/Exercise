//HelloWorld/Task2.kt
package helloWorldExercise2

fun main() {
  println("Hello,")
  println("Kotlin!")
}
