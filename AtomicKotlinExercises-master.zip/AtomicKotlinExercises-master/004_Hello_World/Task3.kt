//HelloWorld/Task3.kt
package helloWorldExercise3

fun main() {
  //println("Hello,")
  println("Kotlin!")
}
