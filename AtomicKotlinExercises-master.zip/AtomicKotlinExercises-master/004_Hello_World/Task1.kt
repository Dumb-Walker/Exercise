//HelloWorld/Task1.kt
package helloWorldExercise1

fun main() {
  println("Hello, Kotlin!")
}
