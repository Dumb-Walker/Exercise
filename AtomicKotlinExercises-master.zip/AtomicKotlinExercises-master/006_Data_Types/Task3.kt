//DataTypes/Task3.kt
package dataTypesExercise3

// 'a' + 1
val c1 = 'b'

// 'a' + 25
val c2 = 'z'

// 'E' - 2
val c3 = 'C'
