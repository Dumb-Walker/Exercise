//DataTypes/Task1.kt
package dataTypesExercise1

fun main() {
  var answer = 42
  // Type mismatch error:
//  answer = "unknown"
  println("Type mismatch")
}
